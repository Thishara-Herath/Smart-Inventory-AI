from pymongo import MongoClient
import numpy as np
from sklearn.linear_model import LinearRegression
from datetime import datetime

# Connect to MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client["smart_inventory_ai"]

inventory_col = db["inventory"]
sales_col = db["sales"]

print("🤖 Smart Inventory Reorder AI\n")

# Process each inventory item
for item in inventory_col.find():
    product = item["product_name"]
    current_stock = item["quantity"]
    reorder_level = item["reorder_level"]

    # Fetch sales history for product
    sales_records = list(sales_col.find({"product_name": product}))

    if len(sales_records) < 2:
        print(f"Not enough sales data for {product}")
        continue

    # Prepare ML data
    days = [r["day"] for r in sales_records]
    units = [r["units_sold"] for r in sales_records]

    X = np.array(days).reshape(-1, 1)
    y = np.array(units)

    # Train ML model
    model = LinearRegression()
    model.fit(X, y)

    # Predict next day's demand
    next_day = max(days) + 1
    predicted_demand = int(model.predict([[next_day]])[0])

    print(f"📦 Product: {product}")
    print(f"Current Stock: {current_stock}")
    print(f"Predicted Demand (Day {next_day}): {predicted_demand}")

    # Smart reorder decision
    if current_stock < predicted_demand:
        reorder_qty = predicted_demand - current_stock + reorder_level
        print(f"🛒 REORDER RECOMMENDED: {reorder_qty} units")
    else:
        print("✅ Stock level is sufficient")

    print("-" * 40)

print("AI check completed at:", datetime.now())
