const API = "http://127.0.0.1:8000"

function getProduct(){
return document.getElementById("productInput").value
}

async function predict(){

const result = document.getElementById("result")

if(result.innerText !== ""){
result.innerText = ""
return
}

const product = getProduct()

const res = await fetch(`${API}/predict/${product}`)
const data = await res.json()

result.innerText = "Predicted Demand: " + data.predicted_sales

}

async function detectSpike(){

const result = document.getElementById("result")

if(result.innerText !== ""){
result.innerText = ""
return
}

const product = getProduct()

const res = await fetch(`${API}/detect-spike/${product}`)
const data = await res.json()

result.innerText = data.message

}

async function seasonal(){

const result = document.getElementById("result")

if(result.innerText !== ""){
result.innerText = ""
return
}

const product = getProduct()

const res = await fetch(`${API}/seasonal-trend/${product}`)
const data = await res.json()

result.innerText = data.message

}

async function reorder(){

const result = document.getElementById("result")

if(result.innerText !== ""){
result.innerText = ""
return
}

const product = getProduct()

const res = await fetch(`${API}/reorder/${product}`)
const data = await res.json()

result.innerText = data.message

}

async function showChart(){

const ctx = document.getElementById("chart")

if(window.demandChart){
window.demandChart.destroy()
window.demandChart = null
return
}

const product = getProduct()

const res = await fetch(`${API}/predict/${product}`)
const data = await res.json()

window.demandChart = new Chart(ctx,{
type:"line",
data:{
labels:["Today","Tomorrow"],
datasets:[{
label:"Demand",
data:[data.current_sales,data.predicted_sales],
borderWidth:3
}]
}
})

}

async function addProduct(){

const product_name = document.getElementById("p_name").value
const category = document.getElementById("p_category").value
const price = parseFloat(document.getElementById("p_price").value)
const quantity = parseInt(document.getElementById("p_quantity").value)
const reorder_level = parseInt(document.getElementById("p_reorder").value)

const res = await fetch(`${API}/add-product`,{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body: JSON.stringify({
product_name,
category,
price,
quantity,
reorder_level
})
})

const data = await res.json()

document.getElementById("productResult").innerText = data.message
loadProducts()

}

async function addSale(){

const product_name = document.getElementById("sale_product").value
const units_sold = parseInt(document.getElementById("sale_units").value)
const day = parseInt(document.getElementById("sale_day").value)

const res = await fetch(`${API}/add-sale`,{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body: JSON.stringify({
product_name,
units_sold,
day
})
})

const data = await res.json()

document.getElementById("saleResult").innerText = data.message
loadProducts()

}

async function loadProducts(){

const res = await fetch(`${API}/products`)
const data = await res.json()

const table = document.getElementById("inventoryTable")

table.innerHTML = `
<tr>
<th>Product</th>
<th>Category</th>
<th>Stock</th>
<th>Price</th>
<th>Actions</th>
</tr>
`

data.products.forEach(p=>{

let stockColor = "green"

if(p.quantity <= p.reorder_level){
stockColor = "red"
}
else if(p.quantity <= p.reorder_level + 5){
stockColor = "orange"
}

table.innerHTML += `
<tr>
<td>${p.product_name}</td>
<td>${p.category}</td>
<td>
<span class="badge" style="background:${stockColor};">
${p.quantity}
</span>
</td>
<td>${p.price}</td>

<td>

<button class="btn btn-sm btn-warning"
onclick="editProduct('${p.product_name}','${p.category}','${p.price}','${p.quantity}','${p.reorder_level}')">
Update
</button>

<button class="btn btn-sm btn-danger"
onclick="deleteProduct('${p.product_name}')">
Delete
</button>

</td>

</tr>
`

})

document.getElementById("inventoryCount").innerText = data.products.length

}

async function deleteProduct(name){

if(!confirm("Delete this product?")) return

const res = await fetch(`${API}/delete-product/${name}`,{
method:"DELETE"
})

const data = await res.json()

alert(data.message)

loadProducts()

}

function editProduct(name,category,price,quantity,reorder){

document.getElementById("update_name").value = name
document.getElementById("update_category").value = category
document.getElementById("update_price").value = price
document.getElementById("update_quantity").value = quantity
document.getElementById("update_reorder").value = reorder

const modal = new bootstrap.Modal(document.getElementById("updateModal"))

modal.show()

}

async function updateProduct(){

const name = document.getElementById("update_name").value
const category = document.getElementById("update_category").value
const price = parseFloat(document.getElementById("update_price").value)
const quantity = parseInt(document.getElementById("update_quantity").value)
const reorder_level = parseInt(document.getElementById("update_reorder").value)

const res = await fetch(`${API}/update-product/${name}`,{

method:"PUT",

headers:{
"Content-Type":"application/json"
},

body: JSON.stringify({
category,
price,
quantity,
reorder_level
})

})

const data = await res.json()

alert(data.message)

loadProducts()

}

async function checkLowStock(){

const list = document.getElementById("lowStockList")

if(list.innerHTML !== ""){
list.innerHTML = ""
return
}

const res = await fetch(`${API}/low-stock`)
const data = await res.json()

data.low_stock.forEach(p=>{

list.innerHTML += `<li>⚠ ${p.product_name} → Stock ${p.quantity}</li>`

})

}

async function loadTopProducts(){

const list = document.getElementById("topProducts")

if(list.innerHTML !== ""){
list.innerHTML = ""
return
}

const res = await fetch(`${API}/top-products`)
const data = await res.json()

data.top_products.forEach(p=>{

list.innerHTML += `<li>${p.product_name} → ${p.total_sold} units</li>`

})

}

async function forecast(){

if(window.forecastChartInstance){
window.forecastChartInstance.destroy()
window.forecastChartInstance = null
return
}

const product = getProduct()

const res = await fetch(`${API}/forecast/${product}`)
const data = await res.json()

const ctx = document.getElementById("forecastChart")

window.forecastChartInstance = new Chart(ctx,{
type:"line",
data:{
labels:["Day+1","Day+2","Day+3","Day+4","Day+5","Day+6","Day+7"],
datasets:[{
label:"Forecast Demand",
data:data.forecast,
borderWidth:3
}]
}
})

}

async function salesHistory(){

if(window.historyChartInstance){
window.historyChartInstance.destroy()
window.historyChartInstance = null
return
}

const product = getProduct()

const res = await fetch(`${API}/sales-history/${product}`)
const data = await res.json()

const ctx = document.getElementById("historyChart")

window.historyChartInstance = new Chart(ctx,{
type:"bar",
data:{
labels:data.days,
datasets:[{
label:"Units Sold",
data:data.units,
borderWidth:1
}]
}
})

}

async function aiRiskCheck(){

const list = document.getElementById("aiRiskList")

if(list.innerHTML !== ""){
list.innerHTML = ""
return
}

const res = await fetch(`${API}/products`)
const data = await res.json()

for(const p of data.products){

const r = await fetch(`${API}/reorder/${p.product_name}`)
const result = await r.json()

if(result.message.toLowerCase().includes("reorder")){

list.innerHTML += `
<li class="list-group-item list-group-item-danger">
🚨 ${p.product_name} → ${result.message}
</li>
`

}

}

if(list.innerHTML === ""){
list.innerHTML = "<li class='list-group-item list-group-item-success'>No AI reorder risks detected</li>"
}

}

window.onload = function(){

//loadProducts()
loadKPIs()
autoAIAlerts()

startAutoRefresh()

}

async function loadInsights(){

const low = document.getElementById("insightLow")
const top = document.getElementById("insightTop")
const seasonal = document.getElementById("insightSeasonal")

// TOGGLE BEHAVIOR
if(low.innerHTML !== "" || top.innerHTML !== "" || seasonal.innerHTML !== ""){
low.innerHTML = ""
top.innerHTML = ""
seasonal.innerHTML = ""
return
}

low.innerHTML = ""
top.innerHTML = ""
seasonal.innerHTML = ""

const productsRes = await fetch(`${API}/products`)
const productsData = await productsRes.json()

// LOW STOCK
const lowRes = await fetch(`${API}/low-stock`)
const lowData = await lowRes.json()

lowData.low_stock.forEach(p=>{
low.innerHTML += `<li class="list-group-item">⚠ ${p.product_name} → ${p.quantity}</li>`
})

// TOP PRODUCTS
const topRes = await fetch(`${API}/top-products`)
const topData = await topRes.json()

topData.top_products.forEach(p=>{
top.innerHTML += `<li class="list-group-item">🔥 ${p.product_name} → ${p.total_sold}</li>`
})

// SEASONAL TREND
for(const p of productsData.products){

const res = await fetch(`${API}/seasonal-trend/${p.product_name}`)
const data = await res.json()

if(data.message.includes("Higher sales")){
seasonal.innerHTML += `
<li class="list-group-item list-group-item-info">
📊 ${p.product_name} → Weekend Demand High
</li>
`
}

}

if(seasonal.innerHTML === ""){
seasonal.innerHTML = "<li class='list-group-item'>No strong seasonal trends detected</li>"
}

}

async function loadKPIs(){

// TOTAL PRODUCTS
const resProducts = await fetch(`${API}/products`)
const dataProducts = await resProducts.json()

document.getElementById("kpiProducts").innerText = dataProducts.products.length


// LOW STOCK
const resLow = await fetch(`${API}/low-stock`)
const dataLow = await resLow.json()

document.getElementById("kpiLowStock").innerText = dataLow.low_stock.length


// TOP SELLER
const resTop = await fetch(`${API}/top-products`)
const dataTop = await resTop.json()

if(dataTop.top_products.length > 0){
document.getElementById("kpiTop").innerText = dataTop.top_products[0].product_name
}


// AI RISK COUNT
let riskCount = 0

for(const p of dataProducts.products){

const r = await fetch(`${API}/reorder/${p.product_name}`)
const result = await r.json()

if(result.message.includes("Reorder")){
riskCount++
}

}

document.getElementById("kpiRisk").innerText = riskCount

}

async function autoAIAlerts(){

const res = await fetch(`${API}/products`)
const data = await res.json()

let riskProducts = []

for(const p of data.products){

const r = await fetch(`${API}/reorder/${p.product_name}`)
const result = await r.json()

if(result.message.includes("Reorder")){
riskProducts.push(p.product_name)
}

}

if(riskProducts.length > 0){

alert(
"⚠ AI Inventory Alert\n\n" +
riskProducts.length + " products may run out of stock soon:\n\n" +
riskProducts.join("\n")
)

}

}

function startAutoRefresh(){

setInterval(() => {

loadProducts()
loadKPIs()

}, 5000) // refresh every 5 seconds

}

function toggleInventory(){

const table = document.getElementById("inventoryTable")

if(table.style.display === "none"){
table.style.display = "table"
}
else{
table.style.display = "none"
}

}

function searchInventory(){

const input = document.getElementById("searchProduct").value.toLowerCase()
const rows = document.querySelectorAll("#inventoryTable tr")

rows.forEach((row, index)=>{

if(index === 0) return

const product = row.children[0].innerText.toLowerCase()

if(product.includes(input)){
row.style.display = ""
}
else{
row.style.display = "none"
}

})

}

async function showInventoryChart(){

if(window.inventoryChartInstance){
window.inventoryChartInstance.destroy()
window.inventoryChartInstance = null
return
}

const res = await fetch(`${API}/products`)
const data = await res.json()

const labels = data.products.map(p => p.product_name)
const quantities = data.products.map(p => p.quantity)

const ctx = document.getElementById("inventoryChart")

window.inventoryChartInstance = new Chart(ctx,{
type:"bar",
data:{
labels:labels,
datasets:[{
label:"Stock Quantity",
data:quantities,
borderWidth:1
}]
}
})

}