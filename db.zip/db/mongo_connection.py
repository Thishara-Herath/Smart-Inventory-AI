from pymongo import MongoClient

def get_database():
    """
    Creates and returns a MongoDB database connection
    """
    client = MongoClient("mongodb://localhost:27017/")
    db = client["smart_inventory_ai"]
    return db
