from pymongo import MongoClient
import numpy as np
from sklearn.linear_model import LinearRegression

# Connect to MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client["smart_inventory_ai"]
sales = db["sales"]

# Fetch sales data
records = list(sales.find({"product_name": "Rice 1kg"}))

# Prepare data for ML
days = []
units = []

for r in records:
    days.append(r["day"])
    units.append(r["units_sold"])

X = np.array(days).reshape(-1, 1)
y = np.array(units)

# Train ML model
model = LinearRegression()
model.fit(X, y)

# Predict future demand (day 6)
future_day = np.array([[6]])
prediction = model.predict(future_day)

print("📊 Demand Prediction using AI")
print("Predicted units to be sold on day 6:", int(prediction[0]))
