from pymongo import MongoClient
from datetime import datetime

# Connect to MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client["smart_inventory_ai"]
inventory = db["inventory"]

print("AI Inventory Alert System\n")

items = inventory.find()

for item in items:
    product = item["product_name"]
    quantity = item["quantity"]
    reorder_level = item["reorder_level"]

    # Low stock alert
    if quantity <= reorder_level:
        print(f"⚠ LOW STOCK ALERT: {product} (Qty: {quantity})")

    # Simulated demand surge detection
    if quantity < reorder_level * 1.5:
        print(f"📈 DEMAND SURGE WARNING: {product}")

print("\nAlert check completed at:", datetime.now())
